#include "stdafx.h"
#include "Ground.h"

void Ground::OnCollisionEnter(Object* obj)
{
	int a = 0;
}

void Ground::OnCollisionStay(Object* obj)
{
}

void Ground::OnCollisionExit(Object* obj)
{
}
