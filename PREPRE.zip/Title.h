#pragma once
#include "GgaetIp.h"

class Title : public Scene
{
public:
	virtual void Init() override;


};

