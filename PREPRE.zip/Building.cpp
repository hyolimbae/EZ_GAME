#include "stdafx.h"
#include "Building.h"

void Building::Init()
{
	_transform = object->GetTransform();
	//_spriteRect = object->GetComponent<Sprite>()->GetTransform()->GetRect();
	//_polydraw = object->GetComponent<PolygonDraw>();

	//pos.push_back(Vector2(_spriteRect.left, _spriteRect.top));
	//pos.push_back(Vector2(_spriteRect.right, _spriteRect.top));

	//_polydraw->SetVertices(pos);
	//_polydraw->SetStrokeWidth(10);

	// + opacity�� 0���� ����.


	_mouseX = InputManager::GetInstance()->GetMousePosition().x;
	_mouseY = InputManager::GetInstance()->GetMousePosition().y;

}

void Building::Update()
{

}

void Building::OnCollisionEnter(Object* obj)
{
	if (obj->GetTag() == "Mouse")
	{
		// + polydraw�� opacity�� ������ ����.

		_isShowInfoBox = true;
	}
}

void Building::OnCollisionStay(Object* obj)
{
}

void Building::OnCollisionExit(Object* obj)
{
	if (obj->GetTag() == "Mouse")
	{
		// + �ٽ� opacity 0���� ����.

		int i = 0;

		_isShowInfoBox = false;
	}
}
