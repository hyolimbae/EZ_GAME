#pragma once
#include "GgaetIp.h"

class InfoBox : public Script
{
private:
	// �ڽ� ��ü ����
	Object* _infoBox;
	Transform* _transform;
	Physics* _physics;
	Sprite* _sprite;

	// �ڽ��� �ؽ�Ʈ ����
	Object* _infoText;
	Text* _text;
	map<string, int> material;
	int time;

	int _numWood;
	int _numStone;
	int _numMud;
	int _numWater;
	int _numGemstone;
	int _numBrick;
	int _numIron;
	int _numPlywood;



public:
	virtual void Init() override;
	virtual void Update() override;

	//virtual void OnCollisionEnter(Object* obj);
	//virtual void OnCollisionStay(Object* obj);
	//virtual void OnCollisionExit(Object* obj);

	void ShowInfoBox();
};