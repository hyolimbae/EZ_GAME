#pragma once
#include "GgaetIp.h"


class Building : public Script
{
	Transform* _transform;

	// Mouse ȿ����
	vector<Vector2> pos;
	PolygonDraw* _polydraw;
	RECT _spriteRect;

	float _mouseX, _mouseY;

	// �޽����ڽ� ȣ���
	bool _isShowInfoBox = false;

	

public:
	virtual void Init() override;
	virtual void Update() override;

	virtual void OnCollisionEnter(Object* obj) override;
	virtual void OnCollisionStay(Object* obj) override;
	virtual void OnCollisionExit(Object* obj) override;

	// getter, setter
	bool GetIsShowInfoBox() { return _isShowInfoBox; }

};