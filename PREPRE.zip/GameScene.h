#pragma once
#include "GgaetIp.h"


class GameScene : public Scene
{
public:
	virtual void Init() override;
};

