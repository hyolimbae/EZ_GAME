#include "stdafx.h"
#include "InfoBox.h"
#include "Building.h"
#include "BuildingInfo.h"

void InfoBox::Init()
{
	// InfoBox ����
	_infoBox = Object::CreateObject();

	_sprite = _infoBox->AddComponent<Sprite>();
	_sprite->SetSprite(Image::CreateImage("Sprite/Need_4K.png"));
	_sprite->GetTransform()->SetPosition(Vector2(object->GetTransform()->GetPosition().x + 250,
													object->GetTransform()->GetPosition().y + 200));

	_transform = _infoBox->GetTransform();

	_infoBox->AddComponent<BoxCollider>();

	_physics = _infoBox->AddComponent<Physics>();
	_physics->SetBodyType(DynamicBody);
	_physics->SetIgnoreCollision(true);
	_physics->SetGravityScale(0);
	
	// ���� �ؽ�Ʈ ����
	//material = object->GetComponent<BuildingInfo>()->GetBuildingInfo()[object->GetTag()].material;
	//time = object->GetComponent<BuildingInfo>()->GetBuildingInfo()[object->GetTag()].time;

	//_numWood = material["����"];
	//_numStone = material["����"];
	//_numMud = material["��"];
	//_numWater = material["��"];
	//_numGemstone = material["����"];
	//_numBrick = material["����"];
	//_numIron = material["ö��"];
	//_numPlywood = material["����"];



	// ���� ��ư ����


}

void InfoBox::Update()
{
	ShowInfoBox();
}

//void InfoBox::OnCollisionEnter(Object* obj)
//{
//
//}
//
//void InfoBox::OnCollisionStay(Object* obj)
//{
//
//}
//
//void InfoBox::OnCollisionExit(Object* obj)
//{
//
//}

void InfoBox::ShowInfoBox()
{
	if (object->GetComponent<Building>()->GetIsShowInfoBox())
	{
		_sprite->SetOpacity(1.f);
	}
	else
	{
		int i = 0;
		_sprite->SetOpacity(0.f);
	}
}