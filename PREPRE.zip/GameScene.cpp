#include "stdafx.h"
#include "GameScene.h"

#include "Mouse.h"
#include "Building.h"
#include "BuildingInfo.h"
#include "InfoBox.h"
#include "Ground.h"

void GameScene::Init()
{
	Object* ground = Object::CreateObject();
	ground->SetTag("Ground");
	auto groundBoxCollider = ground->AddComponent<BoxCollider>();
	groundBoxCollider->SetSize(Vector2(DesignResolution.x, 100));
	ground->GetTransform()->SetPosition(Vector2(0.f, -DesignResolution.y / 2 + groundBoxCollider->GetSize().y / 2));
	ground->AddComponent<Ground>();


	// ���콺
	auto mouse = Object::CreateObject();
	mouse->SetTag("Mouse");
	mouse->AddComponent<Mouse>();
	auto mouseSprite = mouse->AddComponent<Sprite>();
	mouseSprite->SetSprite(Image::CreateImage("Sprite/Mouse_Basic.png"));
	mouseSprite->GetTransform()->SetScale(Vector2(0.5f, 0.5f));
	auto mouseCollider = mouse->AddComponent<BoxCollider>();
	mouseCollider->SetSize(Vector2(100,100));
	//auto mousePhysics = mouse->AddComponent<Physics>();
	//mousePhysics->SetIgnoreCollision(true);
	//mousePhysics->SetGravityScale(0);
	auto mouseSound = mouse->AddComponent<Sound>();
	auto click = AudioClip::CreateSound("Sound/SE/Click.wav");
	mouseSound->SetSound(click);
	ShowCursor(false);

	
	// �ӽ� House
	Object* houseTest = Object::CreateObject();
	houseTest->SetName("Springfield");
	houseTest->AddComponent<Building>();
	houseTest->AddComponent<BuildingInfo>();
	houseTest->AddComponent<InfoBox>();
	
	auto houseTestCollider = houseTest->AddComponent<BoxCollider>();
	houseTestCollider->SetSize(Vector2(90, 100));
	houseTest->GetTransform()->SetPosition(Vector2(0, -110));



}